//Citation: workbook and Chat GPT intergration
//creating leaflet map
function createMap() {
    map = L.map('college_football_map', {
        center: [39.8283, -98.5795],
        zoom: 4
    });

    //add tile layer
    L.tileLayer('https://api.mapbox.com/styles/v1/donaldmi/clonhl9e9003s01r7gnt51ksd/tiles/256/{z}/{x}/{y}@2x?access_token=pk.eyJ1IjoiZG9uYWxkbWkiLCJhIjoiY2xvaXlvYzhzMDBiODJsbW84dDg0OGYycyJ9.R7ApXrX_89B27zOIqDVujg', {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
    }).addTo(map);

    getData();

    //legend
var legend = L.control({ position: 'topright' });

legend.onAdd = function (map) {
    var div = L.DomUtil.create('div', 'info legend');
    var legendContent = '<strong>Legend</strong><br>';
    legendContent += '<div><div class="symbol-small"></div> <5000</div>';
    legendContent += '<div><div class="symbol-medium"></div> <20000</div>';
    legendContent += '<div><div class="symbol-large"></div> 20000+</div>';
    div.innerHTML = legendContent;
    return div;
};

legend.addTo(map);

}


// List of Pac-12 university cities
const pac12Cities = [
    'Tucson',
    'Tempe',
    'Berkeley',
    'Los Angeles',
    'Boulder',
    'Eugene',
    'Corvallis',
    'Stanford',
    'Los Angeles',
    'Salt Lake City',
    'Seattle',
    'Pullman'
];

function getData() {
    // Load the data
    fetch("data/Football_stadiums.geojson")
        .then(function (response) {
            return response.json();
        })
        .then(function (json) {
            // Create a geojson layer with proportional symbols for Pac-12 cities
            L.geoJson(json, {
                pointToLayer: function (feature, latlng) {
                    var city = feature.properties.CITY;
                    var Football_stadiums = feature.properties.NAME1
                    // Check if the city is in the list of Pac-12 cities
                    if (pac12Cities.includes(city)) {
                        // Create a symbol for Pac-12 cities
                        var marker = L.circleMarker(latlng, {
                            radius: 10, // Set a fixed symbol size
                            fillOpacity: 1,
                            color: 'black',
                        });

                        // Popup with the city name
                        marker.bindPopup('City: ' + Football_stadiums);

                        return marker;
                    }
                }
            }).addTo(map);
        });
}


document.addEventListener('DOMContentLoaded', createMap);
